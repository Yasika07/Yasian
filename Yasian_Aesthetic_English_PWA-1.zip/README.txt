YASIAN — FREE INSTALLABLE STUDY APP
1. Upload this folder to a free static host (GitHub Pages is free).
2. Open the published link in Chrome on Android.
3. Chrome menu ⋮ -> Add to Home screen (or Install app).
4. Yasian will appear on your phone home screen like an app.
5. The app UI is English and the data is stored locally on your device.

No paid Thunkable plan is required for this version.
